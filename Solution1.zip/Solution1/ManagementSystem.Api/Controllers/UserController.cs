﻿using ManagementSystem.Api.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ManagementSystem.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        // If using your custom AuthorizationFilter, place it like this on the controller or method
        // [ServiceFilter(typeof(AuthorizationFilter))] // If you registered the filter in DI

        // But if you are doing role-based auth, simply use Authorize
        [HttpGet("admin-data")]
        [TypeFilter(typeof(AuthorizationFilter), Arguments = new object[] { "Admin" })]
        public IActionResult GetAdminData()
        {
            return Ok("This is protected admin data.");
        }


        [Authorize(Roles = "User")]
        [HttpGet("user-data")]
        public IActionResult GetUserData()
        {
            return Ok("This is protected user data.");
        }

        [Authorize] // For any authenticated user
        [HttpGet("common-data")]
        public IActionResult GetCommonData()
        {
            return Ok("This is common protected data for any authenticated user.");
        }
    }
}
