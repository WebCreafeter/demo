﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;

namespace ManagementSystem.Api.Filters
{
    public class AuthorizationFilter : IAuthorizationFilter
    {
        private readonly string _role;

        public AuthorizationFilter(string role)
        {
            _role = role;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var user = context.HttpContext.User;
            if (!user.Identity?.IsAuthenticated ?? true || !user.IsInRole(_role))
            {
                context.Result = new ForbidResult();
            }
        }
    }
}