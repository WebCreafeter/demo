﻿namespace ManagementSystem.Api.Configurations
{
    public class SerilogConfig
    {
    }
}
